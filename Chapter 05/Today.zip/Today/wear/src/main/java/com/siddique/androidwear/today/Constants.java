package com.siddique.androidwear.today;

public class Constants {
    public static final String ON_THIS_DAY_REQUEST = "/today/onThisDayRequest";

    public static final String ON_THIS_DAY_DATA_ITEM_HEADER = "/today/onThisDayHeader";
    public static final String ON_THIS_DAY_DATA_ITEM_CONTENT = "/today/onThisDayContent";
}
